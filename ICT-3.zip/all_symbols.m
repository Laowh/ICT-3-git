function [ result ] = all_symbols( cardinality )

x = produ(cardinality);
result = []
for a =  1 : length(cardinality) 
    i = length(cardinality)-a+1
    for j = 1 : x
        result(j) = [num2str(mod(j,cardinality(i))+1) result(j)]
    
    end
end

end

